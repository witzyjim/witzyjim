<?php
/** Theme bootstrap. */
if (!defined('ABSPATH')) { exit; }
function ia_theme_setup() {
 load_theme_textdomain('invictus-editorial', get_template_directory() . '/languages');
 add_theme_support('title-tag'); add_theme_support('post-thumbnails'); add_theme_support('responsive-embeds');
 add_theme_support('html5', array('search-form','comment-form','comment-list','gallery','caption','style','script'));
 add_theme_support('custom-logo', array('height'=>90,'width'=>280,'flex-width'=>true,'flex-height'=>true));
 add_theme_support('editor-styles'); add_editor_style('assets/site.css');
 add_theme_support('wp-block-styles'); add_theme_support('align-wide');
 register_nav_menus(array('primary'=>__('Primary navigation','invictus-editorial'),'footer'=>__('Footer navigation','invictus-editorial')));
}
add_action('after_setup_theme','ia_theme_setup');
add_action('wp_enqueue_scripts',function(){
 wp_enqueue_style('ia-site',get_template_directory_uri().'/assets/site.css',array(),'1.0.0');
 wp_enqueue_script('ia-site',get_template_directory_uri().'/assets/site.js',array(),'1.0.0',array('strategy'=>'defer','in_footer'=>true));
});
function ia_asset($name) { return get_template_directory_uri().'/assets/'.$name; }
function ia_resources_url() { return post_type_exists('ia_resource') ? get_post_type_archive_link('ia_resource') : 'https://invictusafrica.org/publications/'; }
function ia_primary_menu() {
 echo '<ul class="nav-list"><li><a href="https://invictusafrica.org/about-us/">'.esc_html__('Who we are','invictus-editorial').'</a></li><li><a href="'.esc_url(home_url('/#approach')).'">'.esc_html__('Our approach','invictus-editorial').'</a></li><li><a href="'.esc_url(ia_resources_url()).'">'.esc_html__('Resources','invictus-editorial').'</a></li></ul>';
}
add_action('customize_register',function($c){
 $c->add_section('ia_home',array('title'=>__('Invictus homepage','invictus-editorial'),'priority'=>30));
 $fields=array('ia_eyebrow'=>array('Data. Technology. Accountability.','text'),'ia_headline'=>array("Evidence that\nmoves us\nforward.",'textarea'),'ia_intro'=>array('We turn data into action for inclusive policies, equitable resources and accountable institutions.','textarea'),'ia_hero_alt'=>array('Two women exploring data on a laptop, from Invictus Africa’s existing website.','text'));
 foreach($fields as $key=>$field){$c->add_setting($key,array('default'=>$field[0],'sanitize_callback'=>$field[1]==='textarea'?'sanitize_textarea_field':'sanitize_text_field'));$c->add_control($key,array('section'=>'ia_home','label'=>ucwords(str_replace('_',' ',substr($key,3))),'type'=>$field[1]));}
 $c->add_setting('ia_hero',array('sanitize_callback'=>'absint'));$c->add_control(new WP_Customize_Media_Control($c,'ia_hero',array('label'=>__('Hero photograph','invictus-editorial'),'section'=>'ia_home','mime_type'=>'image')));
});
add_action('init',function(){
 register_block_pattern_category('invictus',array('label'=>__('Invictus Africa','invictus-editorial')));
 register_block_pattern('invictus/statement',array('title'=>__('Editorial statement','invictus-editorial'),'categories'=>array('invictus'),'content'=>'<!-- wp:group {"align":"wide","backgroundColor":"blush","layout":{"type":"constrained"}} --><div class="wp-block-group alignwide has-blush-background-color has-background"><!-- wp:heading {"fontSize":"large"} --><h2 class="wp-block-heading has-large-font-size">Evidence. Insight. Action.</h2><!-- /wp:heading --><!-- wp:paragraph --><p>Add your approved programme introduction here.</p><!-- /wp:paragraph --></div><!-- /wp:group -->'));
});
