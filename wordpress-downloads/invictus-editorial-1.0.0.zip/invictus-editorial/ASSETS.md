# Asset provenance

The design, PHP, JavaScript and CSS are original work produced for this request. They do not contain Malala Fund source code, logo or photography. PHP/JS/CSS theme and plugin code are distributed under GPL-2.0-or-later. Brand imagery retains its original owner's copyright and is not relicensed as generic stock imagery by this project.

- `assets/logo.png`: Invictus Africa's current logo from https://invictusafrica.org/wp-content/uploads/2025/10/Invictus-Logo-New.png
- `assets/hero.jpg`: resized/optimized copy of the existing website hero image at https://invictusafrica.org/wp-content/uploads/2025/10/invictus-africa-slide-one-scaled.jpg . It shows two women exploring data on a laptop. The theme does not claim they are named staff or participants in a particular event.
- The hero seal, arrows, star motifs, abstract Dataly bars and typographic resource panels are original CSS/SVG treatments. The bars are illustrative, not actual figures.
- System fonts are used; no third-party font service or externally hosted JavaScript library is requested by the theme.
- Screenshots are of the new local WordPress staging site and contain no private SharePoint material, credentials or subscriber data.

Source URLs were accessed on 22 October 2026. Confirm current brand guidelines, asset rights/consent and the desired hero image with Invictus Africa's content owner before launch.
