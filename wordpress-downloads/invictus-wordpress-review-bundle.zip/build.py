#!/usr/bin/env python3
"""Package public deliverables only; runtime secrets/database files are excluded."""
from pathlib import Path
import hashlib
import zipfile
from PIL import Image, ImageOps

root=Path(__file__).resolve().parent
out=root/'dist';out.mkdir(exist_ok=True)
shot=out/'invictus-home-desktop-fold.png'
if not shot.exists():raise SystemExit('Capture and review screenshots before packaging.')
ImageOps.fit(Image.open(shot).convert('RGB'),(1200,900)).save(root/'theme/invictus-editorial/screenshot.png')

def archive(path,files,base):
    with zipfile.ZipFile(path,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for file in sorted(files):
            if file.is_file():
                name=str(file.relative_to(base))
                if '.runtime' in file.parts or file.name.startswith('.env'):
                    raise SystemExit('Refusing to package runtime configuration: '+name)
                info=zipfile.ZipInfo(name,(2026,10,22,0,0,0));info.external_attr=0o100644<<16
                z.writestr(info,file.read_bytes(),compress_type=zipfile.ZIP_DEFLATED,compresslevel=9)

archive(out/'invictus-editorial-1.0.0.zip',(root/'theme/invictus-editorial').rglob('*'),root/'theme')
archive(out/'invictus-core-1.0.0.zip',(root/'plugin/invictus-core').rglob('*'),root/'plugin')
public=[root/'README.md',root/'build.py']
for folder in ['theme','plugin','docs','tests']:
    public.extend((root/folder).rglob('*'))
public.extend(out.glob('*.png'))
public.extend([out/'invictus-editorial-1.0.0.zip',out/'invictus-core-1.0.0.zip'])
archive(out/'invictus-wordpress-review-bundle.zip',public,root)
for file in out.glob('*.zip'):
    with zipfile.ZipFile(file) as z:
        assert z.testzip() is None
        assert all(not n.startswith('/') and '..' not in Path(n).parts for n in z.namelist())
checks=[]
for file in sorted(out.iterdir()):
    if file.suffix in ('.zip','.png'):
        checks.append(hashlib.sha256(file.read_bytes()).hexdigest()+'  '+file.name)
(out/'SHA256SUMS').write_text('\n'.join(checks)+'\n')
print('Packaged and verified three ZIPs. No runtime files or credentials included.')
