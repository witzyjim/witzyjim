<?php
// Run only in the disposable, local review installation.
$_SERVER['HTTP_HOST']='127.0.0.1:8088';
require '/var/www/html/wp-load.php';
if(home_url()!=='http://127.0.0.1:8088'){throw new RuntimeException('Refusing to run fixtures outside the isolated review site.');}
$checks=0;
function check($ok,$label){global $checks;if(!$ok){throw new RuntimeException('FAILED: '.$label);} $checks++;echo "PASS: $label\n";}
check(get_template()==='invictus-editorial','Theme active');
check(post_type_exists('ia_resource')&&post_type_exists('ia_programme'),'Portable content types registered');
check(taxonomy_exists('ia_format')&&taxonomy_exists('ia_topic'),'Resource formats and topics registered');
check(ia_core_https('javascript:alert(1)')==='','Javascript URLs rejected');
check(ia_core_https('http://example.org')==='','Non-HTTPS integrations rejected');
check(ia_core_https('https://example.org/data')==='https://example.org/data','HTTPS resource URL preserved');
check(ia_core_https(array('invalid'))==='','Non-string URLs rejected');
$term=wp_insert_term('Review report','ia_format',array('slug'=>'review-report'));
if(is_wp_error($term)){$term=array('term_id'=>get_term_by('slug','review-report','ia_format')->term_id);}
$ids=array();
for($i=0;$i<12;$i++){
 $id=wp_insert_post(array('post_type'=>'ia_resource','post_status'=>'publish','post_title'=>($i<3?'Equity':'Research').' staging QA fixture '.$i,'post_content'=>'This is synthetic staging-only content. Not an Invictus Africa research finding.','post_excerpt'=>'Synthetic staging test item.'));
 $ids[]=$id;if($i%2===0){wp_set_object_terms($id,(int)$term['term_id'],'ia_format');}
}
$draft=wp_insert_post(array('post_type'=>'ia_resource','post_status'=>'draft','post_title'=>'Private staging draft'));
$ids[]=$draft;update_option('ia_review_fixture_ids',$ids);
$request=new WP_REST_Request('GET','/wp/v2/ia_resource');$request->set_param('per_page',100);$response=rest_do_request($request);$data=$response->get_data();
check($response->get_status()===200,'Public resource REST API works');
check(!in_array($draft,array_column($data,'id'),true),'Drafts excluded from public API');
$update=new WP_REST_Request('POST','/wp/v2/ia_resource/'.$ids[0]);$update->set_body_params(array('meta'=>array('ia_resource_url'=>'https://example.org/unauthorized')));$result=rest_do_request($update);
check(in_array($result->get_status(),array(401,403),true),'Anonymous resource metadata updates rejected');
check(get_post_meta($ids[0],'ia_resource_url',true)==='','Protected resource data unchanged');
$editor=wp_insert_user(array('user_login'=>'ia-review-editor','user_pass'=>wp_generate_password(36),'role'=>'editor','user_email'=>'editor@example.invalid'));
if(is_wp_error($editor)){$editor=get_user_by('login','ia-review-editor')->ID;}
wp_set_current_user($editor);$result=rest_do_request($update);
check($result->get_status()===200&&get_post_meta($ids[0],'ia_resource_url',true)==='https://example.org/unauthorized','Authorized editors can maintain public source URLs');
wp_set_current_user(0);
$meta=array('checks'=>$checks,'report_term'=>$term['term_id'],'fixture_ids'=>$ids);
file_put_contents('/tmp/ia-review-fixtures.json',wp_json_encode($meta));
echo "Completed $checks WordPress integration checks.\n";
