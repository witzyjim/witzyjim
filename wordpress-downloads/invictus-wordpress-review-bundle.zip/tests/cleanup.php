<?php
$_SERVER['HTTP_HOST']='127.0.0.1:8088';require '/var/www/html/wp-load.php';
if(home_url()!=='http://127.0.0.1:8088'){exit(1);}
foreach((array)get_option('ia_review_fixture_ids',array()) as $id){wp_delete_post($id,true);}delete_option('ia_review_fixture_ids');
$term=get_term_by('slug','review-report','ia_format');if($term){wp_delete_term($term->term_id,'ia_format');}
$user=get_user_by('login','ia-review-editor');if($user){require_once ABSPATH.'wp-admin/includes/user.php';wp_delete_user($user->ID);}
echo "Staging fixtures removed.\n";
