<?php
/**
 * Plugin Name: Invictus Core
 * Description: Portable resource library, programme content and optional integrations for Invictus Africa. No page-builder dependency.
 * Version: 1.0.0
 * Requires at least: 6.6
 * Requires PHP: 8.1
 * Author: Invictus Africa
 * License: GPL-2.0-or-later
 * Text Domain: invictus-core
 */
if (!defined('ABSPATH')) { exit; }
function ia_core_register() {
 register_post_type('ia_resource',array('labels'=>array('name'=>__('Resources','invictus-core'),'singular_name'=>__('Resource','invictus-core'),'add_new_item'=>__('Add resource','invictus-core')),'public'=>true,'show_in_rest'=>true,'has_archive'=>'resource-library','rewrite'=>array('slug'=>'resource-library'),'menu_icon'=>'dashicons-media-document','supports'=>array('title','editor','excerpt','thumbnail','revisions','custom-fields')));
 register_post_type('ia_programme',array('labels'=>array('name'=>__('Programmes','invictus-core'),'singular_name'=>__('Programme','invictus-core')),'public'=>true,'show_in_rest'=>true,'has_archive'=>true,'rewrite'=>array('slug'=>'programmes'),'menu_icon'=>'dashicons-chart-area','supports'=>array('title','editor','excerpt','thumbnail','revisions')));
 register_taxonomy('ia_format','ia_resource',array('label'=>__('Resource formats','invictus-core'),'hierarchical'=>true,'public'=>true,'show_in_rest'=>true,'rewrite'=>array('slug'=>'resource-format')));
 register_taxonomy('ia_topic',array('ia_resource','ia_programme'),array('label'=>__('Topics','invictus-core'),'hierarchical'=>true,'public'=>true,'show_in_rest'=>true,'rewrite'=>array('slug'=>'topic')));
 register_post_meta('ia_resource','ia_resource_url',array('type'=>'string','single'=>true,'show_in_rest'=>true,'sanitize_callback'=>'ia_core_https','auth_callback'=>function($allowed,$key,$post_id){return current_user_can('edit_post',$post_id);}));
}
add_action('init','ia_core_register');
function ia_core_https($value) {
 $url=esc_url_raw(is_string($value)?$value:'',array('https'));
 return wp_parse_url($url,PHP_URL_SCHEME)==='https'?$url:'';
}
register_activation_hook(__FILE__,function(){ia_core_register();flush_rewrite_rules();});
register_deactivation_hook(__FILE__,function(){unregister_post_type('ia_resource');unregister_post_type('ia_programme');unregister_taxonomy('ia_format');unregister_taxonomy('ia_topic');flush_rewrite_rules();});
add_action('pre_get_posts',function($q){
 if(is_admin()||!$q->is_main_query()||!$q->is_post_type_archive('ia_resource')){return;}
 $q->set('posts_per_page',9);
 if(isset($_GET['resource_search'])&&is_string($_GET['resource_search'])){$q->set('s',sanitize_text_field(wp_unslash($_GET['resource_search'])));}
 if(isset($_GET['format'])&&is_string($_GET['format'])&&$_GET['format']!==''){
  $slug=sanitize_title(wp_unslash($_GET['format']));$term=get_term_by('slug',$slug,'ia_format');
  if($term){$q->set('tax_query',array(array('taxonomy'=>'ia_format','field'=>'slug','terms'=>$slug)));}else{$q->set('post__in',array(0));}
 }
});
add_action('add_meta_boxes',function(){add_meta_box('ia-resource-link',__('Original resource link','invictus-core'),function($post){wp_nonce_field('ia_resource_link','ia_resource_nonce');echo '<label for="ia_resource_url">'.esc_html__('Public HTTPS URL for the source document, data or dashboard. Leave blank for on-page content.','invictus-core').'</label><input style="width:100%;margin-top:8px" type="url" id="ia_resource_url" name="ia_resource_url" value="'.esc_attr(get_post_meta($post->ID,'ia_resource_url',true)).'">';},'ia_resource','normal');});
add_action('save_post_ia_resource',function($id){
 if(defined('DOING_AUTOSAVE')&&DOING_AUTOSAVE||wp_is_post_revision($id)||!current_user_can('edit_post',$id)){return;}
 if(!isset($_POST['ia_resource_nonce'])||!is_string($_POST['ia_resource_nonce'])||!wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['ia_resource_nonce'])),'ia_resource_link')){return;}
 if(isset($_POST['ia_resource_url'])&&is_string($_POST['ia_resource_url'])){update_post_meta($id,'ia_resource_url',ia_core_https(wp_unslash($_POST['ia_resource_url'])));}
});
add_action('admin_menu',function(){add_options_page('Invictus integrations','Invictus integrations','manage_options','invictus-integrations','ia_core_settings');});
add_action('admin_init',function(){
 foreach(array('ia_newsletter_url','ia_assistant_url') as $key){register_setting('ia_integrations',$key,array('type'=>'string','sanitize_callback'=>'ia_core_https','default'=>''));}
});
function ia_core_settings(){
 if(!current_user_can('manage_options')){return;} ?>
 <div class="wrap"><h1>Invictus integrations</h1><p>Integrations are optional and disabled until configured. Never place AI-provider keys or SharePoint credentials here.</p><form action="options.php" method="post"><?php settings_fields('ia_integrations'); ?><table class="form-table"><tr><th><label for="ia_newsletter_url">Newsletter signup URL</label></th><td><input type="url" class="regular-text" name="ia_newsletter_url" id="ia_newsletter_url" value="<?php echo esc_attr(get_option('ia_newsletter_url')); ?>"><p class="description">Public HTTPS signup page from your mailing-list provider. No local subscription storage or pretend success message.</p></td></tr><tr><th><label for="ia_assistant_url">Ask Invictus interface URL</label></th><td><input type="url" class="regular-text" name="ia_assistant_url" id="ia_assistant_url" value="<?php echo esc_attr(get_option('ia_assistant_url')); ?>"><p class="description">Your separately hosted HTTPS chatbot interface. Its server must permit embedding by this website. Leave empty until the chatbot is ready. Visitors load it only when opening the assistant.</p></td></tr></table><?php submit_button(); ?></form></div>
 <?php
}
function ia_core_assistant(){
 $url=ia_core_https(get_option('ia_assistant_url',''));if(!$url){return;}
 ?>
 <button class="button ia-assistant-button" aria-haspopup="dialog" aria-controls="ia-assistant"><?php esc_html_e('Ask Invictus','invictus-core'); ?> <svg class="icon-arrow" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M5 19L19 5M5 5h14v14"/></svg></button><dialog id="ia-assistant" class="ia-assistant-dialog" aria-labelledby="ia-assistant-title"><header><strong id="ia-assistant-title">Ask Invictus</strong><button aria-label="Close assistant">×</button></header><iframe title="Ask Invictus resource assistant" data-src="<?php echo esc_url($url); ?>" referrerpolicy="strict-origin-when-cross-origin" sandbox="allow-scripts allow-forms allow-same-origin allow-popups" loading="lazy"></iframe></dialog>
 <?php
}
