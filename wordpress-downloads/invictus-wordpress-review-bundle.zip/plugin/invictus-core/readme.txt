=== Invictus Core ===
Requires at least: 6.6
Requires PHP: 8.1
Stable tag: 1.0.0
License: GPL-2.0-or-later

Portable resources, programmes, formats/topics, public source links and optional integrations.

== Installation ==
Upload and activate. Publish Resources with native WordPress blocks, assign formats/topics, and provide HTTPS original-source URLs. Visit Settings > Invictus integrations to configure optional newsletter/assistant URLs. Leave them empty until actual services are ready. No credentials belong in these settings.

The Invictus Editorial theme displays the archive/filter controls and optional assistant UI. Content remains in WordPress if the theme changes or the plugin is deactivated. No posts, users or terms are inserted on activation, and no data is deleted on deactivation. No premium dependency is required.

== Privacy ==
This plugin does not itself store subscriber emails, send messages, load analytics or contact an AI provider. A configured newsletter link leads to your signup provider; an optional assistant iframe loads only after the visitor opens it. Review those providers' privacy practices and embedding policy separately.

== Changelog ==
1.0.0 — Initial release.
