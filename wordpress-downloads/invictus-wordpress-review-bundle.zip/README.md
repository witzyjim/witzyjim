# Invictus Africa — Editorial WordPress redesign

An original, restrained WordPress theme informed by Malala Fund's editorial clarity and storytelling, using Invictus Africa's existing navy, magenta and blush palette.

## Deliverables

- **Invictus Editorial:** responsive theme with an editorial homepage, D.A.T.A. disclosures, Dataly feature, resources, normal page/post templates, archive, real search and 404 handling.
- **Invictus Core:** portable resource/programme post types, formats/topics, resource-source metadata, keyword/format filtering, newsletter URL configuration and optional separately hosted Ask Invictus integration.
- Installable theme and plugin ZIPs, actual desktop/mobile screenshots, assessment, installation/migration guide, provenance and validation evidence.

Read `docs/ASSESSMENT.md`, then `docs/INSTALLATION.md`. The live website has not been modified. The earlier chatbot and Android projects are separate and unchanged.

Install the plugin ZIP under Plugins, then the theme ZIP under Appearance. Use a staging copy first, preserve the current site's plugins/content, and approve migration before production. Do not upload the full source/review bundle through WordPress's theme uploader; use the individual installable ZIPs.

Code license: GPL-2.0-or-later. Existing organization imagery retains its copyright; see `docs/ASSETS.md`.
