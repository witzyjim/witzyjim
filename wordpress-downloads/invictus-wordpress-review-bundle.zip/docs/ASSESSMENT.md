# Website assessment and design direction

Reviewed on 22 October 2026. Sources: https://malala.org/, https://invictusafrica.org/, https://invictusafrica.org/about-us/, and Invictus Africa's public WordPress media API. This is a review of public homepage markup, stylesheet declarations, navigation, linked content and available imagery, not an authenticated backend, legal-compliance or complete accessibility/performance audit. No numerical speed or accessibility score is claimed.

## What to learn from Malala Fund

The public site brings its mission, geographic work, grantmaking/advocacy and first-person stories into a clear editorial structure. Its navigation distinguishes organizational information, the work, voices/resources and ways to support. Photography, quotations, illustrated accents and a story-led resource flow give the content personality. The homepage includes “Where we work”, “Hear from girls” and a strong participation message.

For Invictus, the useful principles are a clear mission hierarchy, generous room around content, prominent imagery, distinct section rhythms, curated stories/resources and purposeful calls to action. Invictus has a different mission and content architecture; a large fundraising/donation funnel or country-programme map should not be copied simply because it exists on Malala Fund's website. No Malala Fund code, logo, photography, distinctive illustration or text has been included in the theme.

## What to retain from Invictus Africa

The live homepage describes Invictus as a civic-tech organization using data and technology for inclusive policies/programmes, equitable resources and institutional accountability. Its Develop, Amplify, Train and Assess framework is distinctive and should remain central. The site already links to Dataly, Womanity Index, publications, Orange Pages, surveys and other resources.

Its current published styles repeatedly specify navy #192C51, magenta #A73B7A, blush #FEEBDF and blue-grey #8DA7B1. The new theme uses these, adding an off-white paper background for calmer reading. This is derived from the live site's styles and logo, not a guess at an unpublished brand manual.

The current homepage references Elementor, Move Addons, EmbedPress, MetForm and Contact Form 7 assets, among other plugins. That establishes a multi-plugin front end; it does not prove every plugin is unnecessary or that the site is insecure/slow. The redesign avoids adding another page-builder dependency. Review existing plugin usage on staging before disabling anything, especially forms, embeds or membership features used on other pages.

## Opportunities addressed

| Area | New treatment |
|---|---|
| Mission clarity | One prominent H1, a concise mission, two clear next steps |
| Brand expression | Original Invictus logo, actual brand colours, restrained magenta accents |
| Editorial rhythm | Oversized sans-serif headlines, italic serif accents, generous space, warm surfaces |
| D.A.T.A. framework | Keyboard-operable native disclosure sections with coordinated open state |
| Dataly discovery | Dedicated feature with an explicitly illustrative data graphic and real dashboard link |
| Resources | Portable resource content type, formats/topics, keyword search, combined filters and pagination |
| Navigation | Responsive menu, real WordPress search, keyboard-accessible search dialog |
| Motion | Gentle reveals/hover changes, no forced autoplay or essential scroll-only interactions; reduced-motion support |
| Maintainability | Native editor support and a companion content plugin; no ACF/Elementor dependency |
| Integrations | Optional newsletter signup link and separately hosted chatbot interface, disabled until configured |

## Content and migration decisions

The new mission/headline/captions and framework summaries are editorial proposals based on the existing site's public purpose; the content owner should approve wording before launch. Default resource links refer to actual existing Invictus resources. The stylized resource cover panels are new typographic designs, not reproductions of official publication covers. The Dataly chart is abstract, labelled illustrative and not a statistical claim. There are no invented impact counts, testimonials or donor claims.

The bundled hero photograph and logo come from Invictus Africa's existing media library; see ASSETS.md. Confirm rights and publication consent for the new placement before public deployment. The theme does not import, remove or overwrite current posts, Elementor layouts, media, menus or plugin settings. Existing pages, shortcodes, member areas and embedded forms must be inventoried and checked on staging. Rebuild the homepage in this theme's structure and map URLs before switching the live site.
