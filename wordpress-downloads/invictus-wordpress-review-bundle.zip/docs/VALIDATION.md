# Validation evidence

The theme and companion plugin were installed and activated in actual local WordPress, not a static HTML mockup.

Runtime: WordPress 7.1.3, PHP 8.3, Apache, MariaDB 11.4.

Official container image digests used:
- `wordpress:php8.3-apache@sha256:d42f63cb89ad0eab272c4b393164e63830d0df270009907919f7dcce52b1a20b`
- `mariadb:11.4@sha256:250e1609e93c0e6aecf64bfbab2d84d5e89d2481540fe77447ff6c855c3b1873`

Passed:
- PHP lint on all theme/plugin PHP files and JavaScript syntax checks.
- 12 WordPress integration assertions: activation/content registration, taxonomies, URL sanitization, public REST access, draft exclusion, unauthorized metadata rejection, unchanged protected data and authorized editor updates.
- Six real HTTP archive assertions: first-page size, second-page size, format-only filtering, keyword-only filtering, combined filters and unknown-format empty results. Temporary synthetic fixtures were removed after the test.
- Chromium checks at desktop/mobile sizes: H1 rendering, bundled images decode, search dialog focus and Escape, one-open-at-a-time D.A.T.A. disclosure behavior, mobile menu/Escape, no mobile horizontal overflow, reduced-motion screenshots, malformed array filter parameters, actual WordPress search, real 404 status and no JavaScript page errors.
- Plugin deactivation preserves resource records, and the theme-only homepage renders without the companion plugin.
- JavaScript-disabled mobile navigation and ordinary search form remain available.

Screenshots in `dist/` show the actual local theme. The homepage defaults link to existing public Invictus resources. The empty real resource library has no fabricated publications inserted in WordPress.

Not tested or claimed:
- The live organization's existing database/plugin/layout compatibility, authenticated membership features or production deployment.
- All WordPress/PHP versions named by the minimum compatibility declaration, all browser/assistive-technology combinations, or a formal accessibility certification.
- Live newsletter signup, outbound email, chatbot/SharePoint/WhatsApp operation or analytics/SEO provider behavior. Those integrations need actual configuration and separate checks.
- Numerical PageSpeed/Core Web Vitals scores or a full security audit.
